
#' Generar base de datos de estudiantes
#'
#' @return Data frame con los datos simulados de estudiantes
#' @export
generate_students_data <- function() {
  set.seed(123)
  num_students <- 60000
  students_data <- data.frame(
    ID = 1:num_students,
    Gender = sample(c('Male', 'Female'), num_students, replace = TRUE),
    Age = sample(14:16, num_students, replace = TRUE),
    Region = sample(c('Montevideo','Interior'), num_students, replace = TRUE, prob = c(0.26165, 0.73835)),
    Area = sample(c('Centro', 'Este', 'Norte', 'Oeste', 'Sur'), num_students, replace = TRUE, prob = c(0.07925, 0.15936, 0.16620, 0.17954, 0.41564)),
    Socioeconomic_Status = round(rnorm(num_students, mean = 43.83, sd = 14.1060), 2),
    Study_Center = sample(paste('Centro', 1:500), num_students, replace = TRUE),
    Study_Group = sample(paste('Grupo', LETTERS[1:10]), num_students, replace = TRUE)
  )
  
  students_data <- students_data %>%
    mutate(
      Math_Score = round(rnorm(num_students, mean = 300, sd = 50)),
      Reading_Score = round(rnorm(num_students, mean = 300, sd = 50)),
      Science_Score = round(rnorm(num_students, mean = 300, sd = 50)),
      Math_Level = case_when(
        Math_Score < 250 ~ 'Nivel 1',
        Math_Score >= 250 & Math_Score < 300 ~ 'Nivel 2',
        Math_Score >= 300 & Math_Score < 350 ~ 'Nivel 3',
        Math_Score >= 350 & Math_Score < 400 ~ 'Nivel 4',
        Math_Score >= 400 ~ 'Nivel 5'
      )
    )
  
  return(students_data)
}

#' Guardar base de datos en un archivo CSV
#'
#' @param data Data frame con los datos de estudiantes
#' @param file_path Ruta del archivo CSV a guardar
#' @export
save_students_data <- function(data, file_path) {
  write.csv(data, file_path, row.names = FALSE)
}

#' Realizar muestreo estratificado
#'
#' @param data Data frame con los datos de estudiantes
#' @param sample_size Tamaño de la muestra
#' @return Data frame con la muestra estratificada
#' @export
stratified_sampling <- function(data, sample_size) {
  total_students <- nrow(data)
  
  data <- data %>%
    group_by(Area) %>%
    mutate(
      Stratum_Size = n(),
      Sampling_Weight = total_students / Stratum_Size,
      Inclusion_Probability = sample_size / total_students
    ) %>%
    ungroup()
  
  set.seed(123)
  stratified_sample <- data %>%
    group_by(Area) %>%
    sample_frac(sample_size / total_students) %>%
    ungroup()
  
  return(stratified_sample)
}

#' Realizar muestreo estratificado y por cluster
#'
#' @param data Data frame con los datos de estudiantes
#' @param sample_size Tamaño de la muestra
#' @return Data frame con la muestra estratificada y por clúster
#' @export
stratified_cluster_sampling <- function(data, sample_size) {
  total_students <- nrow(data)
  
  data <- data %>%
    group_by(Area, Study_Center) %>%
    mutate(
      Cluster_Size = n(),
      Total_Cluster_Size = sum(Cluster_Size),
      Stratum_Size = sum(Total_Cluster_Size),
      Sampling_Weight = total_students / Stratum_Size,
      Inclusion_Probability = sample_size / total_students
    ) %>%
    ungroup()
  
  set.seed(123)
  stratified_cluster_sample <- data %>%
    group_by(Area, Study_Center) %>%
    sample_frac(sample_size / total_students) %>%
    ungroup()
  
  return(stratified_cluster_sample)
}

#' Visualizar distribución de puntajes en Matemáticas
#'
#' @param data Data frame con los datos de estudiantes
#' @export
visualize_math_scores <- function(data) {
  ggplot(data, aes(x = Math_Score)) +
    geom_histogram(binwidth = 10, fill = 'blue', alpha = 0.7) +
    labs(title = 'Distribución de puntajes en Matemáticas',
         x = 'Puntaje en Matemáticas', y = 'Frecuencia')
}

#' Visualizar distribución de puntajes en Matemáticas (Muestra Estratificada)
#'
#' @param data Data frame con la muestra estratificada
#' @export
visualize_stratified_math_scores <- function(data) {
  ggplot(data, aes(x = Math_Score, weight = Sampling_Weight)) +
    geom_histogram(binwidth = 10, fill = 'green', alpha = 0.7) +
    labs(title = 'Distribución de Puntajes en Matemáticas (Muestra Estratificada)',
         x = 'Puntaje en Matemáticas', y = 'Frecuencia Ponderada')
}

#' Visualizar distribución de puntajes en Matemáticas (Muestra Estratificada y por Clúster)
#'
#' @param data Data frame con la muestra estratificada y por clúster
#' @export
visualize_cluster_math_scores <- function(data) {
  ggplot(data, aes(x = Math_Score, weight = Sampling_Weight)) +
    geom_histogram(binwidth = 10, fill = 'red', alpha = 0.7) +
    labs(title = 'Distribución de Puntajes Mat. (Muestra Estratificada y por Clúster)',
         x = 'Puntaje en Matemáticas', y = 'Frecuencia Ponderada')
}

#' Visualizar comparación de niveles socioeconómicos por área
#'
#' @param data Data frame con la muestra estratificada y por clúster
#' @export
visualize_socioeconomic_comparison <- function(data) {
  ggplot(data, aes(x = Area, y = Socioeconomic_Status, weight = Sampling_Weight)) +
    geom_boxplot(fill = 'orange', alpha = 0.7) +
    labs(title = 'Comparación de Nivel Socioeconómico por Área',
         x = 'Área', y = 'Nivel Socioeconómico')
}

